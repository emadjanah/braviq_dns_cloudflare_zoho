# braviq_dns_cloudflare_zoho

This repository contains a Python script and GitHub Actions workflow that automates the update of DNS records for the `braviq.group` domain via Cloudflare API, configured to support Zoho Mail EU.

## Features

- Automatically sets MX, SPF, DKIM, and DMARC records
- Compatible with GitHub Actions (manual and push-triggered)
- Supports environment variables and GitHub Secrets

## Setup

1. Copy `.env.example` to `.env` and fill in your values.
2. Add required secrets to your GitHub repo:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ZONE_ID`
   - `DOMAIN`
   - `ZOHO_SPF`
   - `ZOHO_DKIM`
   - `ZOHO_DMARC`

## License

MIT License.
