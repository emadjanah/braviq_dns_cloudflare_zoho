import os
import requests

HEADERS = {
    "Authorization": f"Bearer {os.getenv('CLOUDFLARE_API_TOKEN')}",
    "Content-Type": "application/json"
}

ZONE_ID = os.getenv("CLOUDFLARE_ZONE_ID")
DOMAIN = os.getenv("DOMAIN")

DNS_RECORDS = [
    {"type": "MX", "name": DOMAIN, "content": "mx.zoho.eu", "priority": 10},
    {"type": "TXT", "name": DOMAIN, "content": os.getenv("ZOHO_SPF")},
    {"type": "TXT", "name": f"zoho._domainkey.{DOMAIN}", "content": os.getenv("ZOHO_DKIM")},
    {"type": "TXT", "name": f"_dmarc.{DOMAIN}", "content": os.getenv("ZOHO_DMARC")},
]

def update_dns():
    for record in DNS_RECORDS:
        url = f"https://api.cloudflare.com/client/v4/zones/{ZONE_ID}/dns_records"
        payload = {
            "type": record["type"],
            "name": record["name"],
            "content": record["content"],
            "ttl": 3600,
            "proxied": False
        }
        if "priority" in record:
            payload["priority"] = record["priority"]

        response = requests.post(url, json=payload, headers=HEADERS)
        print(f"{record['type']} record: {response.status_code} - {response.text}")

if __name__ == "__main__":
    update_dns()
